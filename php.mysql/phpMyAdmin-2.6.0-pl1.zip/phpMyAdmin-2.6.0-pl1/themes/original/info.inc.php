<?php
/* $Id: info.inc.php,v 1.2 2004/09/14 14:21:31 nijel Exp $ */
/* Theme information */
$theme_name = 'Original';
$theme_version = 1;
$theme_generation = 1;
?>
